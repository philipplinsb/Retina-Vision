
import io
import os
from google.cloud import vision

# Set the path to the service account key
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "robotvision-424112-8aa43a82eb7d.json"

def detect_objects(image_path):
    """Detects objects in an image."""
    client = vision.ImageAnnotatorClient()

    # Load the image from local file
    with io.open(image_path, 'rb') as image_file:
        content = image_file.read()

    image = vision.Image(content=content)

    # Perform object detection
    objects = client.object_localization(image=image).localized_object_annotations

    if objects:
        # Return the name of the object with the highest score
        return objects[0].name
    else:
        return "Unknown"

# Example usage
#image_path = r"low_score_objects\object_6_score_0.55.jpg"
#detect_objects(image_path)


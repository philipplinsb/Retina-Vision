
import os
import requests
import json
from PIL import Image
from io import BytesIO

# Define paths
json_path = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/Dataset.json"
images_directory = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/images"

# Create the directory if it does not exist
if not os.path.exists(images_directory):
    os.makedirs(images_directory)

# Load and parse the JSON file
with open(json_path, 'r') as f:
    coco_data = json.load(f)

images_info = coco_data['images']

# Function to download and save an image
def download_and_save_image(url, path):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check if the request was successful
        img = Image.open(BytesIO(response.content)).convert('RGB')
        img.save(path)
        print(f"Saved image to {path}")
    except requests.RequestException as e:
        print(f"Failed to download image from {url}. Error: {e}")
    except IOError as e:
        print(f"Failed to save image to {path}. Error: {e}")

# Iterate over each image info in the dataset and download the images
for img_info in images_info:
    file_name = img_info['file_name']
    coco_url = img_info.get('coco_url')

    if coco_url:
        img_path = os.path.join(images_directory, file_name)
        download_and_save_image(coco_url, img_path)
    else:
        print(f"No URL found for image {file_name}")











'''
import os
import requests
import json
from PIL import Image
from io import BytesIO

# Define paths
json_path = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/Dataset.json"
images_directory = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/images"

# Create the directory if it does not exist
if not os.path.exists(images_directory):
    os.makedirs(images_directory)

# Load and parse the JSON file
with open(json_path, 'r') as f:
    coco_data = json.load(f)

images_info = coco_data['images']

# Function to download, resize, and save an image
def download_resize_save_image(url, path, size=(800, 800)):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check if the request was successful
        img = Image.open(BytesIO(response.content)).convert('RGB')
        img = img.resize(size, Image.LANCZOS)
        img.save(path)
        print(f"Saved image to {path}")
    except requests.RequestException as e:
        print(f"Failed to download image from {url}. Error: {e}")
    except IOError as e:
        print(f"Failed to save image to {path}. Error: {e}")

# Iterate over each image info in the dataset and download the images
for img_info in images_info:
    file_name = img_info['file_name']
    coco_url = img_info.get('coco_url')

    if coco_url:
        img_path = os.path.join(images_directory, file_name)
        download_resize_save_image(coco_url, img_path)
    else:
        print(f"No URL found for image {file_name}")
'''
import torch
import torchvision
from torchvision import models, transforms as T
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import os
import shutil
import json
import io
from google.cloud import vision
from Reverse_Image_search import detect_objects

# Define the COCO categories
COCO_CATEGORIES = [
    'category1','person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat',
    'traffic light', 'fire hydrant', 'street sign', 'stop sign', 'parking meter', 'bench',
    'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra',
    'giraffe', 'hat', 'backpack', 'umbrella', 'shoe', 'eye glasses', 'handbag',
    'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite',
    'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket', 'bottle',
    'plate', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana',
    'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza',
    'donut', 'cake', 'chair', 'couch', 'potted plant', 'bed', 'mirror', 'dining table',
    'window', 'desk', 'toilet', 'door', 'tv', 'laptop', 'mouse', 'remote',
    'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator',
    'blender', 'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier',
    'toothbrush', 'hair brush'
]

# Load the RetinaNet model with the correct weights
model = models.detection.retinanet_resnet50_fpn(pretrained=True)

# Transforms
tf_ = T.ToTensor()

# Function to calculate IoU
def calculate_iou(box1, box2):
    x1, y1, x2, y2 = box1
    x1_gt, y1_gt, x2_gt, y2_gt = box2

    xi1 = max(x1, x1_gt)
    yi1 = max(y1, y1_gt)
    xi2 = min(x2, x2_gt)
    yi2 = min(y2, y2_gt)
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)

    box1_area = (x2 - x1) * (y2 - y1)
    box2_area = (x2_gt - x1_gt) * (y2_gt - y1_gt)
    union_area = box1_area + box2_area - inter_area

    iou = inter_area / union_area if union_area != 0 else 0
    return iou

# Function to plot ground truth and detected boxes
def plot_boxes(image, ground_truth_boxes, ground_truth_labels, detected_boxes, detected_labels, scores, iou_threshold, google_labels):
    fig, ax = plt.subplots(1, figsize=(12, 9))
    ax.imshow(image)

    # Plot ground truth boxes in green with labels
    for box, label in zip(ground_truth_boxes, ground_truth_labels):
        x1, y1, x2, y2 = box
        rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='g', facecolor='none')
        ax.add_patch(rect)
        label_text = f'{label}'
        ax.text(x1, y1 - 10, label_text, color='green', fontsize=12, weight='bold')

    # Plot detected boxes in red or black with labels and scores
    for i, (box, label, score) in enumerate(zip(detected_boxes, detected_labels, scores)):
        x1, y1, x2, y2 = box
        overlaps = any(calculate_iou(box, gt_box) >= iou_threshold for gt_box in ground_truth_boxes)
        if overlaps:
            rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='r', facecolor='none')
            ax.add_patch(rect)
            if i in google_labels:
                google_label, google_score = google_labels[i]
                label_text = f'{google_label}: {google_score:.2f}'
                label_color = 'black'
            elif label < len(COCO_CATEGORIES):
                label_text = f'{COCO_CATEGORIES[label]}: {score:.2f}'
                label_color = 'red'
            else:
                label_text = f'Unknown: {score:.2f}'
                label_color = 'red'
            ax.text(x1, y1 - 10, label_text, color=label_color, fontsize=12, weight='bold')

    plt.show()

# Load and parse the JSON file
json_path = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/Dataset.json"
with open(json_path, 'r') as f:
    coco_data = json.load(f)

images_info = coco_data['images']
annotations_info = coco_data['annotations']
categories_info = coco_data['categories']

# Create a mapping from category id to category name
category_id_to_name = {category['id']: category['name'] for category in categories_info}

# Create a mapping from image id to annotations
annotations_by_image = {}
for annotation in annotations_info:
    image_id = annotation['image_id']
    if image_id not in annotations_by_image:
        annotations_by_image[image_id] = []
    annotations_by_image[image_id].append(annotation)

# Create a folder to save the images with scores less than 60%
output_folder = "low_score_objects"
os.makedirs(output_folder, exist_ok=True)

# Path to the images directory
images_directory = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/images"

# Check if the images directory exists
if not os.path.exists(images_directory):
    print(f"Images directory does not exist: {images_directory}")
else:
    print(f"Images directory exists: {images_directory}")

# Initialize a list to store accuracy results and overall metrics
accuracy_results = []
all_true_positives = 0
all_ground_truth_boxes = 0
total_correct_labels = 0
total_detected_labels = 0

# Define desired object classes for visualization (e.g., 'person' and 'car')
desired_classes = ['person', 'car']
desired_class_ids = [COCO_CATEGORIES.index(cls) for cls in desired_classes]

total_accuracy = []
correct_label_percentages = []

# Thresholds
score_threshold = 0.4  # Adjust this value to change the threshold for detected bounding boxes
iou_threshold = 0.7    # IoU threshold for determining correct detections
low_score_threshold = 0.6

# Iterate over each image in the dataset
for img_info in images_info:
    image_id = img_info['id']
    img_path = os.path.join(images_directory, img_info['file_name'])

    # Print image path for debugging
    print(f"Processing image: {img_path}")

    if not os.path.exists(img_path):
        print(f"Image not found: {img_path}")
        continue

    img = Image.open(img_path).convert("RGB")

    # Transform the image and prepare for inference
    transformed = tf_(img)
    batched = transformed.unsqueeze(0)  # Model input
    int_img = (transformed * 255).to(torch.uint8)

    # Set the model to evaluation mode and perform inference
    model.eval()
    with torch.no_grad():
        out = model(batched)

    # Process the output
    scores = out[0]['scores']
    boxes = out[0]['boxes']
    labels = out[0]['labels']

    # Apply Non-Maximum Suppression (NMS)
    keep = torchvision.ops.nms(boxes, scores, iou_threshold)
    boxes = boxes[keep]
    scores = scores[keep]
    labels = labels[keep]

    # Filter out detections by score threshold
    high_score_indices = scores > score_threshold
    detected_boxes = boxes[high_score_indices]
    detected_scores = scores[high_score_indices]
    detected_labels = labels[high_score_indices]

    # Get ground truth annotations for the current image
    if image_id in annotations_by_image:
        ground_truth_boxes = [
            [ann['bbox'][0], ann['bbox'][1], ann['bbox'][0] + ann['bbox'][2], ann['bbox'][1] + ann['bbox'][3]]
            for ann in annotations_by_image[image_id]
        ]  # Convert to [x1, y1, x2, y2] format
        ground_truth_labels = [category_id_to_name[ann['category_id']] for ann in annotations_by_image[image_id]]
    else:
        ground_truth_boxes = []
        ground_truth_labels = []

    # Initialize counters for true positives and ground truth boxes
    true_positives = 0
    correct_labels = 0
    all_ground_truth_boxes += len(ground_truth_boxes)

    # Google labels for low-score detections
    google_labels = {}
    # Process low-scoring detections
    for i, (box, score, label_index) in enumerate(zip(detected_boxes, detected_scores, detected_labels)):
        if score < low_score_threshold:
            x_min, y_min, x_max, y_max = map(int, box.tolist())
            cropped_img = img.crop((x_min, y_min, x_max, y_max))
            cropped_img_path = os.path.join(output_folder, f"object_{i}_score_{score:.2f}.jpg")
            cropped_img.save(cropped_img_path)

            # Detect object in the cropped image using Google Vision API
            detected_label = detect_objects(cropped_img_path)
            google_labels[i] = (detected_label, float(score))

    # Compare detected boxes with ground truth boxes using IoU
    for gt_box, gt_label in zip(ground_truth_boxes, ground_truth_labels):
        for i, (detected_box, detected_label) in enumerate(zip(detected_boxes, detected_labels)):
            detected_box = detected_box.tolist()
            iou = calculate_iou(detected_box, gt_box)
            if iou >= iou_threshold:
                true_positives += 1
                if i in google_labels:
                    if google_labels[i][0] == gt_label:
                        correct_labels += 1
                elif detected_label < len(COCO_CATEGORIES) and COCO_CATEGORIES[detected_label] == gt_label:
                    correct_labels += 1
                break  # One ground truth box should only match with one detected box

    all_true_positives += true_positives
    total_correct_labels += correct_labels
    total_detected_labels += len(detected_boxes)

    # Calculate and store the accuracy for the current image
    accuracy = (true_positives / len(ground_truth_boxes)) * 100 if len(ground_truth_boxes) > 0 else 0
    accuracy_results.append((img_info['file_name'], accuracy))
    print(f"Image: {img_info['file_name']}, % detected ground truths: {accuracy:.2f}%")
    total_accuracy.append(accuracy)

    # Calculate percentage of correctly labeled red bounding boxes
    correct_label_percentage = (correct_labels / true_positives) * 100 if true_positives > 0 else 0
    correct_label_percentages.append(correct_label_percentage)
    print(f"Image: {img_info['file_name']}, Correct Label Percentage: {correct_label_percentage:.2f}%")

    # Plot the boxes for visualization
    plot_boxes(img, ground_truth_boxes, ground_truth_labels, detected_boxes.tolist(), detected_labels.tolist(), detected_scores.tolist(), iou_threshold, google_labels)

# Calculate overall accuracy
#overall_accuracy = (all_true_positives / all_ground_truth_boxes) * 100 if all_ground_truth_boxes > 0 else 0

#-------------------------------------------------------------------------------

print(total_accuracy)
final_tot_accuracy = sum(total_accuracy) / len(total_accuracy)
print(f"Total % detected ground thruths: {final_tot_accuracy:.2f}%")

# Calculate total percentage of correctly labeled red bounding boxes
total_correct_label_percentage = sum(correct_label_percentages) / len(correct_label_percentages) if correct_label_percentages else 0
print(f"Total Correct Label Percentage: {total_correct_label_percentage:.2f}%")

# Write accuracy results to a text file
accuracy_file_path = r"C:/Users/Florian/Documents/TU_Wien/Semester 2/RobotVision/Retina_Net_2/accuracy_results.txt"
with open(accuracy_file_path, 'a') as f:  # Open file in append mode
    f.write("\n" + "="*40 + "\n")  # Add a separator line for new run
    f.write(f"Score Threshold: {score_threshold}\n")
    f.write(f"IoU Threshold: {iou_threshold}\n")
    f.write(f"Low Score Threshold: {low_score_threshold}\n\n")
    for file_name, accuracy in accuracy_results:
        f.write(f"Image: {file_name}, % detected ground truths: {accuracy:.2f}%\n")
    f.write(f"\nTotal % detected ground thruths: {final_tot_accuracy:.2f}%\n")
    f.write(f"Total Correct Label Percentage: {total_correct_label_percentage:.2f}%\n\n")
    final_accuracy = final_tot_accuracy*(total_correct_label_percentage/100)
    f.write(f"Total Accuracy: {final_accuracy:.2f}%\n")

print(f"Accuracy results appended to {accuracy_file_path}")

# Clear out the low_score_objects folder
for filename in os.listdir(output_folder):
    file_path = os.path.join(output_folder, filename)
    try:
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)  # Remove the file
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)  # Remove the directory and its contents
    except Exception as e:
        print(f'Failed to delete {file_path}. Reason: {e}')
